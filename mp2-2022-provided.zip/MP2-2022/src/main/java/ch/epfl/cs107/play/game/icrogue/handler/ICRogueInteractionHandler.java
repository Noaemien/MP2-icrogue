package ch.epfl.cs107.play.game.icrogue.handler;

import ch.epfl.cs107.play.game.areagame.handler.AreaInteractionVisitor;

public interface ICRogueInteractionHandler extends AreaInteractionVisitor {

}
